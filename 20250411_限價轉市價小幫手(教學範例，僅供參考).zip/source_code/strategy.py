import multiprocessing
import threading
import time
import logging
import json
import utils
import datetime
import uuid
import hashlib
import traceback
from abc import ABC, abstractmethod
from zoneinfo import ZoneInfo
from sdk_manager_async import SDKManager, check_sdk
from fubon_neo.sdk import Order
from fubon_neo.constant import TimeInForce, OrderType, PriceType, MarketType, BSAction
from concurrent.futures import ThreadPoolExecutor, wait

class Strategy(ABC):
    """
    Strategy template class
    """
    __version__ = "2024.0.7"

    def __init__(self, logger=None, log_level=logging.DEBUG):
        # Set logger
        log_shutdown_event = None
        if logger is None:
            current_date = datetime.datetime.now(ZoneInfo("Asia/Taipei")).date().strftime("%Y-%m-%d")
            utils.mk_folder("log")
            logger, log_shutdown_event = utils.get_logger(
                name="Strategy",
                log_file=f"log/strategy_{current_date}.log",
                log_level=log_level
            )

        self.logger = logger
        self.logger_shutdown = log_shutdown_event

        # The sdk_manager
        self.sdk_manager: SDKManager | None = None

    """
        Public Functions
    """

    def set_sdk_manager(self, sdk_manager: SDKManager):
        self.sdk_manager = sdk_manager
        # self.logger.info(f"The SDKManager version: {self.sdk_manager.__version__}")

    @check_sdk
    def add_realtime_marketdata(self, symbol: str):
        """
         Add a realtime trade data websocket channel
        :param symbol: stock symbol (e.g., "2881")
        """
        self.sdk_manager.subscribe_realtime_trades(symbol)

    @check_sdk
    def remove_realtime_marketdata(self, symbol: str):
        """
        Remove a realtime market data websocket channel
        :param symbol: stock symbol (e.g., "2881")
        """
        self.sdk_manager.unsubscribe_realtime_trades(symbol)

    @abstractmethod
    @check_sdk
    def run(self):
        """
        Strategy logic to be implemented.
        """
        raise NotImplementedError("Subclasses must implement this method")


class TradeCondition:
    def __init__(self, symbol:str , mode: int, qty: int, side: int, logger: logging.Logger):
        # Initialize Attributes
        self.symbol: str = symbol  # 股票代號
        self.mode: int = mode  # 執行模式: 0-開盤價出現，先抽後送; 1-08:59:59連續送單
        self.qty: int = qty  # 交易張數 (1=1張)
        self.side: int = side  # 0-買漲停; 1-賣跌停

        self.__logger: logging.Logger = logger

        # The ID of this condition
        self.__id = self.__generate_id()

        # Order status keeper of this condition
        self.__orders: dict = {
            "limit_order": None,
            "market_order": None,
            "filled_data": {},  # filled_num -> filled_qty
        }

        self.__lock: threading.Lock = threading.Lock()

    def __generate_id(self) -> str:
        def generate_unique_string():
            # Get the current timestamp as a string
            current_timestamp = str(time.time())
            # Combine the symbol with the timestamp
            combined = self.symbol + current_timestamp
            # Create a SHA256 hash of the combined string
            hash_obj = hashlib.sha256(combined.encode('utf-8'))
            # Return the hex digest
            return hash_obj.hexdigest()

        # Helper function to convert an integer to a base62 string.
        def base62_encode(num, characters):
            base = len(characters)
            if num == 0:
                return characters[0]
            encoded = ""
            while num:
                num, rem = divmod(num, base)
                encoded = characters[rem] + encoded
            return encoded

        # Generate a random UUID
        u = uuid.uuid4()
        # To restrict our ID to 10 characters in base62, we use modulo 62^10.
        max_val = 62 ** 10
        short_int = u.int % max_val
        # Convert the resulting integer to base62.
        short_str = base62_encode(short_int, generate_unique_string())
        # Pad with leading zeros if necessary to ensure it has 10 characters.
        return short_str.zfill(10)

    def regenerate_id(self):
        self.__id = self.__generate_id()

    def get_id(self) -> str:
        return self.__id

    def generate_limit_order(self) -> (None|Order, str):
        if self.__orders["limit_order"] is not None:
            return None, f"Cond {self.__id}: The limit order has already been sent"

        err_message = ""
        order = None
        try:
            order = Order(
                buy_sell = BSAction.Buy if self.side == 0 else BSAction.Sell,
                symbol = self.symbol,
                price = None,
                quantity = int(self.qty * 1000),
                market_type = MarketType.Common,
                price_type = PriceType.LimitUp if self.side == 0 else PriceType.LimitDown,
                time_in_force = TimeInForce.ROD,
                order_type = OrderType.Stock,
                user_def = f"{self.__id}"
            )

        except Exception as err:
            err_message = f"Cond {self.__id} exception: {err}, \n{traceback.format_exc()}"

        finally:
            return order, err_message

    def generate_market_order(self) -> (None|Order, str):
        if self.qty <= self.get_total_filled_qty():
            return None, f"Cond {self.__id}: No more qty need to be filled"

        err_message = ""
        order = None
        try:
            order = Order(
                buy_sell = BSAction.Buy if self.side == 0 else BSAction.Sell,
                symbol = self.symbol,
                price = None,
                quantity = int((self.qty - self.get_total_filled_qty()) * 1000),
                market_type = MarketType.Common,
                price_type = PriceType.Market,
                time_in_force = TimeInForce.ROD,
                order_type = OrderType.Stock,
                user_def = f"{self.__id}"
            )

        except Exception as err:
            err_message = f"Cond {self.__id} exception: {err}, \n{traceback.format_exc()}"

        finally:
            return order, err_message

    # CALLBACK UPDATERS #########################
    def push_on_order(self, order_result, id_check):
        if id_check != self.__id:
            print(f"Cond {self.__id} push_on_order ID check failed: {id_check}")
            return

        try:
            with self.__lock:
                if order_result.price_type == PriceType.Market:
                    self.__orders["market_order"] = order_result

                else:
                    self.__orders["limit_order"] = order_result

        except Exception as err:
            self.__logger.error(f"Cond {self.__id} push_on_order exception: {err}, \n{traceback.format_exc()}")

    def push_on_order_change(self, order_result, id_check):
        if id_check != self.__id:
            self.__logger.error(f"Cond {self.__id} push_on_order_change ID check failed: {id_check}")
            return

        try:
            with self.__lock:
                if order_result.status == 90:
                    self.__logger.error(f"Cond {self.__id} push_on_order_change did not act since status is 90")
                    return

                # Update the order
                if order_result.price_type == PriceType.Market:
                    self.__orders["market_order"] = order_result

                else:
                    self.__orders["limit_order"] = order_result

        except Exception as err:
            self.__logger.error(f"Cond {self.__id} push_on_order_change exception: {err}, \n{traceback.format_exc()}")

    def push_on_filled(self, filled_data, id_check):
        if id_check != self.__id:
            self.__logger.error(f"Cond {self.__id} push_on_filled ID check failed: {id_check}")
            return

        try:
            with self.__lock:
                self.__orders["filled_data"][filled_data.filled_no] = int(filled_data.filled_qty / 1000)

        except Exception as err:
            self.__logger.error(f"Cond {self.__id} push_on_filled exception: {err}, \n{traceback.format_exc()}")

    # ORDER STATUS INQUIRY #########################
    def get_limit_order(self):
        return self.__orders["limit_order"]

    def get_market_order(self):
        return self.__orders["market_order"]

    def get_filled_data(self):
        return self.__orders["filled_data"].copy()

    def get_total_filled_qty(self):
        return sum(self.__orders["filled_data"].values())


class SodaBeer(Strategy):
    __version__ = "2025.1.0.0"
    __exchange_open__ = datetime.time(8, 31)
    __pre_market_open__ = datetime.time(8, 59, 59, 500)
    __market_open__ = datetime.time(9, 00)
    __market_close__ = datetime.time(13, 31)

    def __init__(self,
                 in_queue: multiprocessing.Queue,
                 out_queue: multiprocessing.Queue,
                 sdk_manager: SDKManager,
                 logger=None,
                 log_level=logging.DEBUG):

        super().__init__(logger=logger, log_level=log_level)

        # Info
        self.logger.info(f"SodaBeer version: {self.__version__}")

        # Agent State
        self.is_alive: bool = True

        # Multiprocessing Queue
        self.__in_queue: multiprocessing.Queue = in_queue
        self.__out_queue: multiprocessing.Queue = out_queue

        # Condition Coordinators
        self.__trade_conditions: dict[str, TradeCondition] = {}  # condition id -> TradeCondition
        self.__condition_count: dict[str, int] = {}  # By symbol
        self.__active_conditions: list[str] = []  # ids
        self.__is_running_conditions: dict[str, bool] = {}  # condition id -> True or False
        self.__stop_early: dict[str, bool] = {}

        self.__price_data: dict[str, dict] = {}

        # Set the SDK manager
        self.set_sdk_manager(sdk_manager)

        # ThreadPoolExecutor
        self.__threadpool_executor = ThreadPoolExecutor()

        # The Threads
        self.__thread_lock: threading.Lock = threading.Lock()
        self.__main_thread: threading.Thread = threading.Thread(
            target=self.__main_executor
        )
        self.__operation_thread: threading.Thread | None = None

        self.__main_thread.start()

    # AUXILIARY ######################
    def set_sdk_manager(self, sdk_manager: SDKManager):
        try:
            super().set_sdk_manager(sdk_manager)
            self.sdk_manager.set_trade_handle_func("on_order", self.__on_order)
            self.sdk_manager.set_trade_handle_func("on_order_changed", self.__on_order_change)
            self.sdk_manager.set_trade_handle_func("on_filled", self.__on_filled)
            self.sdk_manager.set_ws_handle_func("message", self.__marketdata_callback)

        except Exception as err:
            self.logger.error(f"Setting SDK manager exception: {err},\n {traceback.format_exc()}")

    # OPERATION THREAD ######################

    # Basically wait for the command and do something
    def __main_executor(self):
        while self.is_alive:
            # Run the blocking queue.get() in a separate thread
            try:
                msg = self.__in_queue.get(timeout=5)
                # print(msg)
                data = json.loads(msg)

                command = data.get("command", "")
                request_id = data.get("request_id", "")
                reply_msg = {}

                match command:
                    case "add_condition":
                        try:
                            symbol = f"{data['symbol']}"
                            mode = int(data["mode"])
                            qty = int(data["qty"])
                            side = int(data["side"])
                            trade_cond = TradeCondition(symbol=symbol,
                                                        mode=mode,
                                                        qty=qty,
                                                        side=side,
                                                        logger=self.logger)

                            while trade_cond.get_id() in self.__trade_conditions:
                                self.logger.warning(f"Cond id {trade_cond.get_id()} already exists, regenerating id!")
                                trade_cond.regenerate_id()

                            # Add new condition
                            cond_id = trade_cond.get_id()
                            self.__trade_conditions[cond_id] = trade_cond
                            self.__active_conditions.append(cond_id)  # Default is activated

                            # Subscribe the price data
                            self.sdk_manager.subscribe_realtime_trades(trade_cond.symbol)

                        except Exception as err:
                            self.logger.warning(f"Process {command} failed. Exception: {err}, \n{traceback.format_exc()}")
                            self.logger.debug(f"msg: {msg}")

                            cond_id = None

                        # The reply message
                        reply_msg = {
                            "command": command,
                            "request_id": request_id,
                            "cond_id": cond_id
                        }

                    case "remove_condition":
                        result = False

                        try:
                            cond_id = f"{data['cond_id']}"

                            if cond_id in self.__trade_conditions:
                                # Remove the condition
                                del(self.__trade_conditions[cond_id])

                            result = True

                        except Exception as err:
                            self.logger.warning(f"Process {command} failed. Exception: {err}, \n{traceback.format_exc()}")
                            self.logger.debug(f"msg: {msg}")

                        # The reply message
                        reply_msg = {
                            "command": command,
                            "request_id": request_id,
                            "result": result
                        }

                    case "deactivate_condition":
                        result = False

                        try:
                            cond_id = f"{data['cond_id']}"

                            if cond_id in self.__active_conditions:
                                # Remove the condition
                                self.__active_conditions.remove(cond_id)

                            result = True

                        except Exception as err:
                            self.logger.warning(f"Process {command} failed. Exception: {err}, \n{traceback.format_exc()}")
                            self.logger.debug(f"msg: {msg}")

                            # The reply message
                        reply_msg = {
                            "command": command,
                            "request_id": request_id,
                            "result": result
                        }

                    case "activate_condition":
                        result = False

                        try:
                            cond_id = f"{data['cond_id']}"

                            if cond_id not in self.__trade_conditions:
                                self.logger.warning(f"cond_id {cond_id} is not in the list!")
                                self.logger.debug(f"msg: {msg}")
                            else:
                                if cond_id not in self.__active_conditions:
                                    # Remove the condition
                                    self.__active_conditions.append(cond_id)

                                result = True

                        except Exception as err:
                            self.logger.warning(f"Process {command} failed. Exception: {err}, \n{traceback.format_exc()}")
                            self.logger.debug(f"msg: {msg}")

                        # The reply message
                        reply_msg = {
                            "command": command,
                            "request_id": request_id,
                            "result": result
                        }

                    case "start_operation":
                        result = False

                        try:
                            if (self.__operation_thread is not None) and self.__operation_thread.is_alive():
                                self.logger.warning(f"The operation is already on!")
                                self.logger.debug(f"msg: {msg}")

                            else:
                                self.run()
                                while self.__operation_thread is None or (not self.__operation_thread.is_alive()):
                                    self.logger.info(f"Waiting operation thread to start ...")
                                    time.sleep(1)

                            result = True

                        except Exception as err:
                            self.logger.warning(f"Process {command} failed. Exception: {err}, \n{traceback.format_exc()}")
                            self.logger.debug(f"msg: {msg}")

                        # The reply message
                        reply_msg = {
                            "command": command,
                            "request_id": request_id,
                            "result": result
                        }

                    case "stop_operation":
                        result = False

                        try:
                            if (self.__operation_thread is None) or (not self.__operation_thread.is_alive()):
                                self.logger.warning(f"The operation is already off!")
                                self.logger.debug(f"msg: {msg}")

                            else:
                                for key in self.__stop_early:
                                    self.__stop_early[key] = True

                                while self.__operation_thread is not None and (self.__operation_thread.is_alive()):
                                    self.logger.info(f"Waiting operation thread to stop ...")
                                    time.sleep(1)

                            result = True

                        except Exception as err:
                            self.logger.warning(
                                f"Process {command} failed. Exception: {err}, \n{traceback.format_exc()}")
                            self.logger.debug(f"msg: {msg}")

                        # The reply message
                        reply_msg = {
                            "command": command,
                            "request_id": request_id,
                            "result": result
                        }

                    case "terminate":
                        self.is_alive = False
                        continue

                    case "query_status":
                        reply_msg = self.__query_status(request_id)

                    case _:
                        self.logger.warning(f"Unknown command {command}, msg: {msg}")

                # Reply the message
                json_msg = json.dumps(reply_msg)
                self.__out_queue.put_nowait(json_msg)

            except Exception as err:
                pass

            finally:
                # Dispose stopped operation thread
                with self.__thread_lock:
                    if (self.__operation_thread is not None) and (not self.__operation_thread.is_alive()):
                        self.__operation_thread = None

                        # Send operation thread stopped message
                        msg = {
                            "command": "notify",
                            "message": "條件執行緒完成運作"
                        }
                        json_msg = json.dumps(msg)
                        self.__out_queue.put_nowait(json_msg)

    def __query_status(self, request_id):
        status = []

        try:
            for k, v in self.__trade_conditions.items():
                cond_status = {
                    "cond_id": k,
                    "symbol": v.symbol,
                    "mode": v.mode,
                    "qty": v.qty,
                    "side": v.side,
                    "limit_order": False if v.get_limit_order() is None else True,
                    "market_order": False if v.get_market_order() is None else True,
                    "filled_qty": v.get_total_filled_qty(),
                    "is_active": True if k in self.__active_conditions else False,
                    "is_running": self.__is_running_conditions[k] if k in self.__is_running_conditions else False
                }
                status.append(cond_status)

        except Exception as err:
            self.logger.debug(f"__query_status exception: {err}, \n{traceback.format_exc()}")

        msg = {
            "command": "query_status",
            "request_id": request_id,
            "data": status
        }

        return msg

    # Terminate
    def terminate(self):
        self.is_alive = False
        self.__main_thread.join(timeout=5)
        self.logger_shutdown.set()

    # OPERATION THREAD ######################
    # Start trading
    def run(self):
        if self.__operation_thread is not None:
            self.logger.warning("The agent is already running, do not call running again.")
            return

        else:
            self.logger.debug("Start operation ...")
            with self.__thread_lock:
                self.__operation_thread = threading.Thread(
                    target=self.__trading
                )
                self.__operation_thread.start()

    def __trading(self):
        futures = []

        for key, cond in self.__trade_conditions.items():
            if key in self.__active_conditions:
                self.logger.debug(f"Starting condition {key} ...")
                self.__is_running_conditions[key] = True
                self.__stop_early[key] = False
                future = self.__threadpool_executor.submit(self.__trading_task, key)
                futures.append(future)
            else:
                self.logger.debug(f"Condition {key} is not active, pass")

        # Wait for all futures to be completed
        wait(futures)

        # Flag all conditions have stopped running
        for key in self.__is_running_conditions:
            self.__is_running_conditions[key] = False

    # Trading logic for single condition
    def __trading_task(self, cond_id):
        if cond_id not in self.__trade_conditions:
            self.logger.error(f"The condition id {cond_id} is not in the list!")
            self.__is_running_conditions[cond_id] = False
            return

        try:
            # Get the condition
            trade_cond = self.__trade_conditions[cond_id]

            # Executing the condition
            early_bird_msg_sent = False

            while (not self.__stop_early[cond_id]) and\
                    (trade_cond.get_market_order() is None) and \
                    (trade_cond.get_total_filled_qty() < trade_cond.qty):

                now_time = datetime.datetime.now(ZoneInfo("Asia/Taipei")).time()

                if now_time < self.__exchange_open__:
                    if not early_bird_msg_sent:
                        today = datetime.date.today()
                        dt1 = datetime.datetime.combine(today, self.__exchange_open__)
                        dt2 = datetime.datetime.combine(today, now_time)
                        self.logger.info(f"Cond {cond_id}: 等待交易所開門, time diff {dt1 - dt2}")
                        early_bird_msg_sent = True

                elif now_time < self.__market_close__:
                    if now_time < self.__pre_market_open__:
                        if trade_cond.get_limit_order() is None:
                            result = None
                            order, msg = trade_cond.generate_limit_order()

                            if order is not None:
                                result = self.sdk_manager.sdk.stock.place_order(
                                    self.sdk_manager.active_account,
                                    order,
                                    unblock=False
                                )

                                self.logger.info(f"Cond {trade_cond.get_id()}: Place the limit order, result: {result}")
                            else:
                                self.logger.info(f"Cond {trade_cond.get_id()}: Cannot place the limit order, msg: {msg}")

                            # Send notify message
                            notify_msg = None
                            if result is None:
                                notify_msg = {
                                    "command": "notify",
                                    "message": f"Condition ID {cond_id} 下限價單失敗, 訊息: {msg}"
                                }

                            elif not result.is_success:
                                notify_msg = {
                                    "command": "notify",
                                    "message": f"Condition ID {cond_id} 下限價單失敗, 訊息: {result.message}"
                                }

                            if notify_msg is not None:
                                json_msg = json.dumps(notify_msg)
                                self.__out_queue.put_nowait(json_msg)

                    else:
                        if trade_cond.mode == 0:  # 先抽後送
                            # Wait until market open (i.e., price is available)
                            if (trade_cond.symbol not in self.__price_data) or \
                                    (self.__price_data[trade_cond.symbol]["price"] is None) or \
                                    (not self.__price_data[trade_cond.symbol]["is_open"] and
                                            not self.__price_data[trade_cond.symbol]["is_continue"]):
                                continue

                            # Try to cancel the limit order
                            limit_order = trade_cond.get_limit_order()
                            if (limit_order is not None) and (limit_order.status not in [30, 40]):
                                self.sdk_manager.sdk.stock.cancel_order(
                                    self.sdk_manager.active_account,
                                    limit_order,
                                    unblock = True
                                )

                            # Place the market order
                            result = None
                            order, msg = trade_cond.generate_market_order()

                            if order is not None:
                                result = self.sdk_manager.sdk.stock.place_order(
                                    self.sdk_manager.active_account,
                                    order,
                                    unblock=False
                                )

                                self.logger.info(f"Cond {trade_cond.get_id()}: Place the market order, result: {result}")
                            else:
                                self.logger.info(f"Cond {trade_cond.get_id()}: Cannot place the market order, msg: {msg}")

                            # Send notify message
                            notify_msg = None

                            if result is None:
                                notify_msg = {
                                    "command": "notify",
                                    "message": f"Condition ID {cond_id} 下市價單失敗, 訊息: {msg}"
                                }

                            elif not result.is_success:
                                notify_msg = {
                                    "command": "notify",
                                    "message": f"Condition ID {cond_id} 下市價單失敗, 訊息: {result.message}"
                                }

                            if notify_msg is not None:
                                json_msg = json.dumps(notify_msg)
                                self.__out_queue.put_nowait(json_msg)

                            # Stop the operation
                            self.__stop_early[cond_id] = True

                        elif trade_cond.mode == 1:  # 連續送, 送成功抽
                            result = None
                            order, msg = trade_cond.generate_market_order()

                            if order is not None:
                                # Place the market order
                                result = self.sdk_manager.sdk.stock.place_order(
                                    self.sdk_manager.active_account,
                                    order,
                                    unblock=False
                                )

                                self.logger.info(f"Cond {trade_cond.get_id()}: Place the market order, result: {result}")
                            else:
                                self.logger.info(f"Cond {trade_cond.get_id()}: Cannot place the market order, msg: {msg}")

                            # Send notify message
                            notify_msg = None

                            if result is None:
                                notify_msg = {
                                    "command": "notify",
                                    "message": f"Condition ID {cond_id} 無法下市價單, 訊息: {msg}"
                                }

                            if not result.is_success:
                                notify_msg = {
                                    "command": "notify",
                                    "message": f"Condition ID {cond_id} 下市價單失敗, 訊息: {result.message}"
                                }

                            if notify_msg is not None:
                                json_msg = json.dumps(notify_msg)
                                self.__out_queue.put_nowait(json_msg)

                            if (result is not None) and result.is_success:  # Try to cancel the limit order
                                limit_order = trade_cond.get_limit_order()
                                if (limit_order is not None) and (limit_order.status not in [30, 40]):
                                    self.sdk_manager.sdk.stock.cancel_order(
                                        self.sdk_manager.active_account,
                                        limit_order,
                                        unblock=True
                                    )

                                # Stop the operation because the market order is successfully placed
                                self.__stop_early[cond_id] = True
                        else:
                            self.logger.error(f"Cond {cond_id}: 模式定義錯誤, mode: {trade_cond.mode}")
                            break

                else:
                    self.logger.info(f"Cond {cond_id}: 市場已收盤，不動作")
                    break

                if now_time < self.__pre_market_open__:
                    time.sleep(1)

        except Exception as err:
            self.logger.error(f"Task operation for cond {cond_id} exception: {err}, \n{traceback.format_exc()}")

        finally:
            self.__is_running_conditions[cond_id] = False

    # CALLBACKS ######################
    # Price data
    def __marketdata_callback(self, data):
        try:
            symbol = data["symbol"]
            price = data.get("price", None)
            price = float(price) if price is not None else price
            is_continues = data.get("isContinuous", False)
            is_limit_down_price = data.get("isLimitDownPrice", False)
            is_limit_up_price = data.get("isLimitUpPrice", False)
            is_open = data.get("isOpen", False)
            data_time = utils.timestamp_to_datetime(data["time"], tz=ZoneInfo("Asia/Taipei"))

            price_data = {
                "price": price,
                "is_continue": is_continues,
                "is_open": is_open,
                "is_limit_up": is_limit_up_price,
                "is_limit_down": is_limit_down_price,
                "datetime": data_time
            }

            # Update the newest price data
            self.__price_data[symbol] = price_data

        except Exception as err:
            self.logger.debug(f"marketdata exception: {err}, \n{traceback.format_exc()}")

    # on_order callback
    def __on_order(self, code, content):
        try:
            status = content.status
            cond_id = content.user_def if content.user_def is not None else ""

            if (status % 10 == 0) and (cond_id in self.__trade_conditions):
                self.__trade_conditions[cond_id].push_on_order(content, cond_id)

            else:
                self.logger.debug(f"Irrelevant new order info, ignore. \n{content}")

        except Exception as err:
            self.logger.error(f"on_order exception: {err}, \n{traceback.format_exc()}")

    # on_order_change callback
    def __on_order_change(self, code, content):
        try:
            status = content.status
            cond_id = content.user_def if content.user_def is not None else ""

            if (status % 10 == 0) and (status != 90) and (cond_id in self.__trade_conditions):
                self.__trade_conditions[cond_id].push_on_order_change(content, cond_id)

            else:
                self.logger.debug(f"Irrelevant order change info, ignore. \n{content}")

        except Exception as err:
            self.logger.error(f"on_order_change exception: {err}, \n{traceback.format_exc()}")

    # on_filled callback
    def __on_filled(self, code, content):
        try:
            cond_id = content.user_def if content.user_def is not None else ""

            if cond_id in self.__trade_conditions:
                self.__trade_conditions[cond_id].push_on_filled(content, cond_id)

            else:
                self.logger.debug(f"Irrelevant filled info, ignore. \n{content}")

        except Exception as err:
            self.logger.error(f"on_filled exception: {err}, \n{traceback.format_exc()}")


def starting_agent_soda_beer(
        in_queue: multiprocessing.Queue,
        out_queue: multiprocessing.Queue,
        account_no: str, personal_id: str, passwd: str, cert_path: str, cert_passwd: str|None=None
):
    # Set up SDK manager
    sdk_manager = SDKManager()
    __test__ = False

    if __test__:
        sdk_manager.login(
            id=personal_id,
            trade_password=passwd,
            cert_filepath=cert_path,
            cert_password=cert_passwd,
            connection_ip="wss://neoapitest.fbs.com.tw/TASP/XCPXWS"
        )
    else:
        sdk_manager.login(
            id=personal_id,
            trade_password=passwd,
            cert_filepath=cert_path,
            cert_password=cert_passwd,
        )
    sdk_manager.set_active_account_by_account_no(account_no)

    # SodaBeer
    soda_beer = SodaBeer(
        in_queue=in_queue,
        out_queue=out_queue,
        sdk_manager=sdk_manager
    )

    while soda_beer.is_alive:
        time.sleep(5)

    # Terminate
    soda_beer.terminate()
    sdk_manager.terminate()

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    pass
