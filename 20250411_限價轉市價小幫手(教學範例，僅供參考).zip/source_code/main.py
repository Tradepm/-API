import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import tkinter.scrolledtext as st
import json
import uuid
import time
import os
import multiprocessing
from cryptography.fernet import Fernet

# Import the trading bot entry point from main.py
from strategy import starting_agent_soda_beer

# Login modal
CONFIG_FILE = "login_config.json"
KEY_FILE = "login_info_key"

def get_encryption_key():
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, "rb") as f:
            return f.read()
    else:
        key = Fernet.generate_key()
        with open(KEY_FILE, "wb") as f:
            f.write(key)
        return key

# Create a global cipher instance
KEY = get_encryption_key()
CIPHER = Fernet(KEY)

def load_login_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "rb") as f:
                encrypted_data = f.read()
            decrypted_data = CIPHER.decrypt(encrypted_data)
            return json.loads(decrypted_data.decode('utf-8'))
        except Exception:
            return {}
    return {}

def save_login_config(config):
    try:
        plaintext = json.dumps(config).encode('utf-8')
        encrypted = CIPHER.encrypt(plaintext)
        with open(CONFIG_FILE, "wb") as f:
            f.write(encrypted)
    except Exception as e:
        print("儲存登入資訊錯誤:", e)

# The login dialog as a Toplevel modal window.
class LoginDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("登入資訊")
        self.geometry("550x220")
        self.resizable(False, False)
        self.transient(parent)
        self.iconbitmap('sodabeer.ico')
        self.grab_set()

        # Load previous config if available.
        config = load_login_config()
        default_personal_id = config.get("personal_id", "")
        default_password = config.get("password", "")
        default_cert_filepath = config.get("cert_filepath", "")
        default_cert_password = config.get("cert_password", "")
        default_account_no = config.get("account_no", "")

        # Create StringVars for all fields.
        self.personal_id_var = tk.StringVar(value=default_personal_id)
        self.password_var = tk.StringVar(value=default_password)
        self.cert_filepath_var = tk.StringVar(value=default_cert_filepath)
        self.cert_password_var = tk.StringVar(value=default_cert_password)
        self.account_no_var = tk.StringVar(value=default_account_no)
        self.disable_cert_password_var = tk.BooleanVar(value=False)

        # Layout
        pad_opts = {'padx': 10, 'pady': 5}

        row = 0
        tk.Label(self, text="身分字號:").grid(row=row, column=0, sticky=tk.W, **pad_opts)
        tk.Entry(self, textvariable=self.personal_id_var, width=30).grid(row=row, column=1, **pad_opts)

        row += 1
        tk.Label(self, text="交易密碼:").grid(row=row, column=0, sticky=tk.W, **pad_opts)
        tk.Entry(self, textvariable=self.password_var, show="*", width=30).grid(row=row, column=1, **pad_opts)

        row += 1
        tk.Label(self, text="憑證檔案位置:").grid(row=row, column=0, sticky=tk.W, **pad_opts)
        cert_frame = tk.Frame(self)
        cert_frame.grid(row=row, column=1, sticky=tk.W, **pad_opts)
        self.cert_entry = tk.Entry(cert_frame, textvariable=self.cert_filepath_var, width=23)
        self.cert_entry.pack(side=tk.LEFT)
        tk.Button(cert_frame, text="瀏覽", command=self.select_cert_file).pack(side=tk.LEFT, padx=5)

        row += 1
        tk.Label(self, text="憑證密碼:").grid(row=row, column=0, sticky=tk.W, **pad_opts)
        self.cert_pw_entry = tk.Entry(self, textvariable=self.cert_password_var, show="*", width=30)
        self.cert_pw_entry.grid(row=row, column=1, **pad_opts)
        # Add check box to disable certificate password
        tk.Checkbutton(self, text="使用預設密碼", variable=self.disable_cert_password_var,
                       command=self.toggle_cert_password).grid(row=row, column=2, sticky=tk.W, **pad_opts)

        row += 1
        tk.Label(self, text="使用帳號（註:開頭0不輸入）:").grid(row=row, column=0, sticky=tk.W, **pad_opts)
        tk.Entry(self, textvariable=self.account_no_var, width=30).grid(row=row, column=1, **pad_opts)

        # OK and Cancel buttons
        button_frame = tk.Frame(self)
        button_frame.grid(row=row+1, column=0, columnspan=3, pady=15)
        tk.Button(button_frame, text="確認", width=10, command=self.on_ok).pack(side=tk.LEFT, padx=10)
        tk.Button(button_frame, text="取消", width=10, command=self.on_cancel).pack(side=tk.LEFT, padx=10)

        self.result = None

        # Center the dialog on the parent window
        self.update_idletasks()
        x = parent.winfo_rootx() + (parent.winfo_width() // 2) - (self.winfo_width() // 2)
        y = parent.winfo_rooty() + (parent.winfo_height() // 2) - (self.winfo_height() // 2)
        self.geometry(f"+{x}+{y}")

    def toggle_cert_password(self):
        if self.disable_cert_password_var.get():
            self.cert_pw_entry.config(state=tk.DISABLED)
            self.cert_password_var.set("")
        else:
            self.cert_pw_entry.config(state=tk.NORMAL)

    def select_cert_file(self):
        filename = filedialog.askopenfilename(title="Select Certificate File")
        if filename:
            self.cert_filepath_var.set(filename)

    def on_ok(self):
        # Validate that required fields are provided.
        if not self.personal_id_var.get().strip():
            messagebox.showwarning("輸入錯誤", "請輸入身分證字號")
            return
        if not self.password_var.get().strip():
            messagebox.showwarning("輸入錯誤", "請輸入交易密碼")
            return
        if not self.cert_filepath_var.get().strip():
            messagebox.showwarning("輸入錯誤", "請設定憑證檔案位置")
            return
        if not self.disable_cert_password_var.get() and not self.cert_password_var.get().strip():
            messagebox.showwarning("輸入錯誤", "請輸入憑證密碼或選取使用預設密碼")
            return
        if not self.account_no_var.get().strip():
            messagebox.showwarning("輸入錯誤", "請輸入交易帳號")
            return

        # Prepare result.
        self.result = {
            "personal_id": self.personal_id_var.get().strip(),
            "password": self.password_var.get().strip(),
            "cert_filepath": self.cert_filepath_var.get().strip(),
            "cert_password": None if self.disable_cert_password_var.get() else self.cert_password_var.get().strip(),
            "account_no": self.account_no_var.get().strip()
        }
        # Save configuration so next time user does not need to retype.
        save_login_config(self.result)
        self.destroy()

    def on_cancel(self):
        self.result = None
        self.destroy()

def get_login_info():
    # Create a temporary root.
    root = tk.Tk()
    # Make the root completely transparent.
    root.attributes("-alpha", 0)
    dialog = LoginDialog(root)
    root.wait_window(dialog)
    login_info = dialog.result
    root.destroy()
    return login_info

# Helper function to generate a unique request ID
def generate_request_id():
    return str(uuid.uuid4())

class TradingBotGUI(tk.Tk):
    def __init__(self, in_queue: multiprocessing.Queue, out_queue: multiprocessing.Queue):
        super().__init__()
        self.title("蘇打啤酒")
        self.geometry("1000x600")
        self.iconbitmap('sodabeer.ico')
        self.in_queue = in_queue
        self.out_queue = out_queue

        # Flag to indicate if the operation is running
        self.operation_running = False
        self.operation_running_timestamp = time.time()

        # Build GUI elements
        self.create_widgets()

        # Start polling the out_queue for messages
        self.poll_queue()
        # Start periodic status query (every 1.5 sec)
        self.after(1500, self.send_query_status)

    def create_widgets(self):
        # ----- Input Frame: Add new trade condition -----
        input_frame = tk.LabelFrame(self, text="新增委託單條件", padx=5, pady=5)
        input_frame.pack(fill=tk.X, padx=10, pady=5)

        # Symbol input
        tk.Label(input_frame, text="股號:").grid(row=0, column=0, sticky=tk.W)
        self.symbol_entry = tk.Entry(input_frame, width=10)
        self.symbol_entry.grid(row=0, column=1, padx=5)

        # Mode selection (0 or 1)
        tk.Label(input_frame, text="模式:").grid(row=0, column=2, sticky=tk.W)
        self.mode_var = tk.StringVar(value="先抽後送")
        self.mode_menu = ttk.Combobox(input_frame, textvariable=self.mode_var,
                                      values=["先抽後送", "送送送"], width=10, state="readonly")
        self.mode_menu.grid(row=0, column=3, padx=5)

        # Side selection (Buy/Sell)
        tk.Label(input_frame, text="交易方向:").grid(row=0, column=4, sticky=tk.W)
        self.side_var = tk.StringVar(value="Buy")
        self.side_menu = ttk.Combobox(input_frame, textvariable=self.side_var,
                                      values=["Buy", "Sell"], width=7, state="readonly")
        self.side_menu.grid(row=0, column=5, padx=5)

        # Quantity input
        tk.Label(input_frame, text="委託張數:").grid(row=0, column=6, sticky=tk.W)
        self.qty_entry = tk.Entry(input_frame, width=10)
        self.qty_entry.grid(row=0, column=7, padx=5)

        # Button to add condition
        self.add_button = tk.Button(input_frame, text="新增條件", command=self.add_condition)
        self.add_button.grid(row=0, column=8, padx=10)

        # ----- Table Frame: Show trade conditions -----
        table_frame = tk.LabelFrame(self, text="委託條件", padx=5, pady=5)
        table_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        # Define columns: active flag, cond_id, symbol, mode, qty, side, limit_order, market_order, filled_qty, is_running
        # columns = ("active", "cond_id", "symbol", "mode", "qty", "side",
        #            "limit_order", "market_order", "filled_qty", "is_running")
        columns = ("啟用", "條件ID", "股號", "模式", "張數", "交易方向",
                   "限價單送出", "市價單送出", "成交張數", "運作中")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", selectmode="browse")
        for col in columns:
            self.tree.heading(col, text=col.replace("_", " ").title())
            self.tree.column(col, width=90, anchor=tk.CENTER)
        self.tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # ----- Action Buttons Frame -----
        action_frame = tk.Frame(self)
        action_frame.pack(fill=tk.X, padx=10, pady=5)
        self.activate_button = tk.Button(action_frame, text="啟用條件", command=self.activate_condition)
        self.activate_button.pack(side=tk.LEFT, padx=5)
        self.deactivate_button = tk.Button(action_frame, text="停止啟用", command=self.deactivate_condition)
        self.deactivate_button.pack(side=tk.LEFT, padx=5)
        self.remove_button = tk.Button(action_frame, text="移除條件", command=self.remove_condition)
        self.remove_button.pack(side=tk.LEFT, padx=5)
        self.run_button = tk.Button(action_frame, text="開始執行", command=self.run_operation)
        self.run_button.pack(side=tk.RIGHT, padx=5)
        self.stop_button = tk.Button(action_frame, text="停止執行", command=self.stop_operation, state=tk.DISABLED)
        self.stop_button.pack(side=tk.RIGHT, padx=5)

        # ----- Notifications Frame -----
        notify_frame = tk.LabelFrame(self, text="通知訊息", padx=5, pady=5)
        notify_frame.pack(fill=tk.BOTH, padx=10, pady=5, expand=True)
        self.notify_text = st.ScrolledText(notify_frame, state=tk.DISABLED, height=8)
        self.notify_text.pack(fill=tk.BOTH, expand=True)

    def add_condition(self):
        symbol = self.symbol_entry.get().strip()
        mode = self.mode_var.get().strip()
        side_str = self.side_var.get().strip()
        qty_str = self.qty_entry.get().strip()

        if not symbol or not mode or not side_str or not qty_str:
            messagebox.showwarning("輸入錯誤", "請確認所有欄位已輸入")
            return

        try:
            # mode_int = int(mode)
            mode_int = 1 if mode == "送送送" else 0
            qty_int = int(qty_str)
            side_int = 0 if side_str.lower() == "buy" else 1
        except Exception as e:
            messagebox.showerror("輸入錯誤", f"無效內容: {e}")
            return

        req_id = generate_request_id()
        msg = {
            "command": "add_condition",
            "request_id": req_id,
            "symbol": symbol,
            "mode": mode_int,
            "side": side_int,
            "qty": qty_int
        }
        self.in_queue.put_nowait(json.dumps(msg))
        self.append_notify(f"加入委託條件, id: {req_id}")

    def remove_condition(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("選取錯誤", "請先點選欲刪除條件")
            return
        # Since we use cond_id as the item iid, we can directly use the selected item id
        cond_id = selected[0]
        req_id = generate_request_id()
        msg = {
            "command": "remove_condition",
            "request_id": req_id,
            "cond_id": cond_id
        }
        self.in_queue.put_nowait(json.dumps(msg))
        self.append_notify(f"移除條件: {cond_id}")

    def activate_condition(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("選取錯誤", "請先點選欲啟用條件")
            return
        cond_id = selected[0]
        req_id = generate_request_id()
        msg = {
            "command": "activate_condition",
            "request_id": req_id,
            "cond_id": cond_id
        }
        self.in_queue.put_nowait(json.dumps(msg))
        self.append_notify(f"啟用條件: {cond_id}")

    def deactivate_condition(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("選取錯誤", "請先點選欲停止啟用條件")
            return
        cond_id = selected[0]
        req_id = generate_request_id()
        msg = {
            "command": "deactivate_condition",
            "request_id": req_id,
            "cond_id": cond_id
        }
        self.in_queue.put_nowait(json.dumps(msg))
        self.append_notify(f"停止啟用條件: {cond_id}")

    def run_operation(self):
        req_id = generate_request_id()
        msg = {
            "command": "start_operation",
            "request_id": req_id
        }
        self.in_queue.put_nowait(json.dumps(msg))
        self.append_notify("開始執行")
        self.operation_running = True
        self.opreation_running_timestamp = time.time()
        self.set_input_state(disabled=True)
        self.run_button.config(state=tk.DISABLED)
        self.stop_button.config(state=tk.NORMAL)

    def stop_operation(self):
        req_id = generate_request_id()
        msg = {
            "command": "stop_operation",
            "request_id": req_id
        }
        self.in_queue.put_nowait(json.dumps(msg))
        self.append_notify("停止執行")
        self.stop_button.config(state=tk.DISABLED)

    def set_input_state(self, disabled: bool):
        state = tk.DISABLED if disabled else tk.NORMAL
        self.symbol_entry.config(state=state)
        self.mode_menu.config(state="readonly" if not disabled else tk.DISABLED)
        self.side_menu.config(state="readonly" if not disabled else tk.DISABLED)
        self.qty_entry.config(state=state)
        self.add_button.config(state=state)
        self.activate_button.config(state=state)
        self.deactivate_button.config(state=state)
        self.remove_button.config(state=state)

    def send_query_status(self):
        req_id = generate_request_id()
        msg = {
            "command": "query_status",
            "request_id": req_id
        }
        self.in_queue.put_nowait(json.dumps(msg))
        self.after(1500, self.send_query_status)

    def poll_queue(self):
        while True:
            try:
                msg_str = self.out_queue.get_nowait()
            except Exception:
                break
            try:
                data = json.loads(msg_str)
                # print(data)
                command = data.get("command", "")
                if command == "query_status":
                    self.update_table(data.get("data", []))
                    if self.operation_running and (time.time() - self.operation_running_timestamp) > 5:
                        # Enable interaction only if all conditions are not running.
                        if all(not d.get("is_running", False) for d in data.get("data", [])):
                            #self.append_notify("停止執行，可重新調整條件")
                            self.operation_running = False
                            self.set_input_state(disabled=False)
                            self.run_button.config(state=tk.NORMAL)
                            self.stop_button.config(state=tk.DISABLED)
                elif command == "notify":
                    message = data.get("message", "")
                    self.append_notify(message)
                else:
                    self.append_notify(f"收到回覆: {msg_str}")
            except Exception as e:
                self.append_notify(f"訊息處理錯誤: {e}")
        self.after(500, self.poll_queue)

    def update_table(self, conditions):
        # Preserve current selection by collecting the selected condition IDs.
        old_selected = set(self.tree.selection())

        # Clear current table
        for item in self.tree.get_children():
            self.tree.delete(item)
        # Insert new rows assigning the condition ID as the item ID (iid).
        for cond in conditions:
            active = "Yes" if cond.get("is_active", False) else "No"
            mode = "送送送" if cond.get("mode", "") == 1 else "先抽後送"
            side = "Buy" if cond.get("side", 0) == 0 else "Sell"
            limit_order = "Yes" if cond.get("limit_order", False) else "No"
            market_order = "Yes" if cond.get("market_order", False) else "No"
            filled_qty = cond.get("filled_qty", 0)
            is_running = "Yes" if cond.get("is_running", False) else "No"
            values = (active,
                      cond.get("cond_id", ""),
                      cond.get("symbol", ""),
                      mode,
                      cond.get("qty", ""),
                      side,
                      limit_order,
                      market_order,
                      filled_qty,
                      is_running)
            cond_id = cond.get("cond_id", "")
            self.tree.insert("", tk.END, iid=cond_id, values=values)
        # Restore selection if the condition still exists.
        new_iids = self.tree.get_children()
        restore_selection = [iid for iid in new_iids if iid in old_selected]
        self.tree.selection_set(restore_selection)

    def append_notify(self, message: str):
        self.notify_text.config(state=tk.NORMAL)
        timestamp = time.strftime("%H:%M:%S")
        self.notify_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.notify_text.see(tk.END)
        self.notify_text.config(state=tk.DISABLED)

    def on_close(self):
        req_id = generate_request_id()
        msg = {
            "command": "terminate",
            "request_id": req_id
        }
        try:
            self.in_queue.put_nowait(json.dumps(msg))
        except Exception:
            pass
        self.destroy()

def main():
    # First, show the login modal to collect login info.
    login_info = get_login_info()
    if login_info is None:
        print("登入取消!")
        return

    in_queue = multiprocessing.Queue()
    out_queue = multiprocessing.Queue()

    # Start the trading bot process with login info.
    bot_process = multiprocessing.Process(
        target=starting_agent_soda_beer,
        args=(in_queue, out_queue,
              login_info["account_no"],
              login_info["personal_id"],
              login_info["password"],
              login_info["cert_filepath"],
              login_info["cert_password"])
    )
    bot_process.start()

    app = TradingBotGUI(in_queue, out_queue)
    app.protocol("WM_DELETE_WINDOW", app.on_close)
    app.mainloop()

    bot_process.join(timeout=5)


if __name__ == '__main__':
    multiprocessing.freeze_support()
    main()

