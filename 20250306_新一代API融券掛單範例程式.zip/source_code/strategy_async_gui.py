import os
import sys
import time
import logging
import threading
import multiprocessing
import tkinter as tk
from tkinter import ttk
from dotenv import load_dotenv

# Import from another local files
import utils
from strategy_async import FubonMarginHero
from sdk_manager_async import SDKManager

# ============================================================
# GUI Process Function (tkinter)
# ============================================================
def gui_process(cmd_queue, status_queue, logger=None):
    class TradingBotGUI(tk.Tk):
        def __init__(self, logger=logging.getLogger("GUI")):
            # Logger
            self.logger = logger

            # Slack variables
            self.symbol_entry = None
            self.target_entry = None
            self.per_round_entry = None

            # Sorting order: dictionary to store current sort order per column.
            self.sorting_order = {}  # e.g., {"symbol": False, "target": True, ...}
            # Variable to store the time when trading was started.
            self.trading_start_time = None

            # GUI
            super().__init__()
            self.title("搶券周年慶")
            self.geometry("900x400")
            self.iconbitmap(r".\ticket_logo.ico")
            # Local storage for stock info.
            # For each symbol, store: {target, per_round, secured, stop, pause, error}
            self.stock_data = {}
            self.create_widgets()
            # Initially, only "Add Stock", "Remove Selected" and "Start Trading" are enabled.
            self.set_buttons_idle()
            self.refresh_status()
            # Set protocol to catch window closing.
            self.protocol("WM_DELETE_WINDOW", self.on_closing)

        def create_widgets(self):
            # --- Input Frame for Adding Stocks ---
            input_frame = tk.Frame(self)
            input_frame.pack(pady=10)
            tk.Label(input_frame, text="股號:").grid(row=0, column=0, padx=5)
            self.symbol_entry = tk.Entry(input_frame, width=8)
            self.symbol_entry.grid(row=0, column=1, padx=5)
            tk.Label(input_frame, text="目標總張數:").grid(row=0, column=2, padx=5)
            self.target_entry = tk.Entry(input_frame, width=5)
            self.target_entry.grid(row=0, column=3, padx=5)
            tk.Label(input_frame, text="每單張數:").grid(row=0, column=4, padx=5)
            self.per_round_entry = tk.Entry(input_frame, width=5)
            self.per_round_entry.grid(row=0, column=5, padx=5)
            # Store Add Stock button reference.
            self.add_btn = tk.Button(input_frame, text="加入股票", command=self.add_stock)
            self.add_btn.grid(row=0, column=6, padx=5)

            # --- Treeview for Displaying Stock List and Status ---
            # Added the "symbol" column as the first column.
            columns = ("symbol", "target", "per_round", "secured", "status", "pause", "error")
            self.tree = ttk.Treeview(self, columns=columns, show="headings")
            # Set up headings with sorting callback.
            for col, header in zip(columns,
                                   ["股號", "目標總張數", "每單張數", "委託成功張數", "運作狀態", "暫停", "錯誤"]):
                self.tree.heading(col, text=header, command=lambda _col=col: self.sort_column(_col))
                self.tree.column(col, width=100, anchor=tk.CENTER)
                # Initialize sorting order (False for ascending by default)
                self.sorting_order[col] = False

            self.tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

            # Configure tags for row coloring.
            self.tree.tag_configure("error", background="pink")
            self.tree.tag_configure("running", background="light green")
            self.tree.tag_configure("pause", background="light yellow")

            # --- Button Frame ---
            btn_frame = tk.Frame(self)
            btn_frame.pack(pady=10)
            # Store button references.
            self.remove_btn = tk.Button(btn_frame, text="移除選取股票", command=self.remove_stock)
            self.remove_btn.pack(side=tk.LEFT, padx=5)
            self.start_btn = tk.Button(btn_frame, text="開始下單", command=self.start_trading)
            self.start_btn.pack(side=tk.LEFT, padx=5)
            self.stop_all_btn = tk.Button(btn_frame, text="停止全部下單", command=self.stop_all)
            self.stop_all_btn.pack(side=tk.LEFT, padx=5)
            self.stop_selected_btn = tk.Button(btn_frame, text="停止選取下單", command=self.stop_selected)
            self.stop_selected_btn.pack(side=tk.LEFT, padx=5)

        def set_buttons_trading(self):
            # When trading is running, disable add/remove/start and enable stop buttons.
            self.add_btn.config(state="disabled")
            self.remove_btn.config(state="disabled")
            self.start_btn.config(state="disabled")
            self.stop_all_btn.config(state="normal")
            self.stop_selected_btn.config(state="normal")

        def set_buttons_idle(self):
            # When trading is not running, enable add/remove/start and disable stop buttons.
            self.add_btn.config(state="normal")
            self.remove_btn.config(state="normal")
            self.start_btn.config(state="normal")
            self.stop_all_btn.config(state="disabled")
            self.stop_selected_btn.config(state="disabled")

        def add_stock(self):
            symbol = self.symbol_entry.get().strip()
            try:
                target = int(self.target_entry.get())
                per_round = int(self.per_round_entry.get())
            except ValueError:
                self.logger.error("Invalid input. Target and Lots per Round must be integers.")
                return

            if symbol:
                # Add to local storage.
                self.stock_data[symbol] = {
                    "target": target,
                    "per_round": per_round,
                    "secured": 0,
                    "stop": True,    # Initially stopped.
                    "pause": False,
                    "error": False
                }
                # Include the symbol as the first column.
                self.tree.insert("", "end", iid=symbol,
                                 values=(symbol, target, per_round, 0, "未啟動", "未暫停", "OK"))
                # Send command to main process.
                cmd_queue.put({
                    "action": "add_stock",
                    "symbol": symbol,
                    "target": target,
                    "per_round": per_round
                })
                # Clear entry fields.
                self.symbol_entry.delete(0, tk.END)
                self.target_entry.delete(0, tk.END)
                self.per_round_entry.delete(0, tk.END)

        def remove_stock(self):
            selected = self.tree.selection()
            for symbol in selected:
                if symbol in self.stock_data:
                    del self.stock_data[symbol]
                self.tree.delete(symbol)
                cmd_queue.put({"action": "remove_stock", "symbol": symbol})

        def start_trading(self):
            # Start trading (for all symbols) by sending the command.
            cmd_queue.put({"action": "start_trading"})
            self.logger.debug("Sent start trading command.")
            # Record the start time and set button states to trading mode.
            self.trading_start_time = time.time()
            self.set_buttons_trading()

        def stop_all(self):
            # Stop trading for all symbols.
            cmd_queue.put({"action": "stop_all"})
            self.logger.debug("Sent stop-all command.")

        def stop_selected(self):
            selected = self.tree.selection()
            for symbol in selected:
                cmd_queue.put({"action": "stop_symbol", "symbol": symbol})
            self.logger.debug("Sent stop command for selected symbols.")

        def refresh_status(self):
            # Update the local display from status messages.
            try:
                while True:
                    update = status_queue.get_nowait()
                    symbol = update.get("symbol")
                    if symbol in self.stock_data:
                        self.stock_data[symbol]["secured"] = update.get("secured", 0)
                        self.stock_data[symbol]["stop"] = update.get("stop", True)
                        self.stock_data[symbol]["pause"] = update.get("pause", False)
                        self.stock_data[symbol]["error"] = update.get("error", False)
                        status_str = "運作中" if not self.stock_data[symbol]["stop"] else "未啟動"
                        pause_str = "暫停" if self.stock_data[symbol]["pause"] else "未暫停"
                        error_str = "錯誤" if self.stock_data[symbol]["error"] else "OK"
                        # Determine the row tag based on flags.
                        # Priority: error > running > pause > default.
                        if self.stock_data[symbol]["error"]:
                            tag = "error"
                        elif not self.stock_data[symbol]["stop"]:
                            tag = "running"
                        elif self.stock_data[symbol]["pause"]:
                            tag = "pause"
                        else:
                            tag = ""
                        # Update the row including the symbol in the first column.
                        self.tree.item(symbol, values=(
                            symbol,
                            self.stock_data[symbol]["target"],
                            self.stock_data[symbol]["per_round"],
                            self.stock_data[symbol]["secured"],
                            status_str,
                            pause_str,
                            error_str
                        ), tags=(tag,))
            except Exception:
                # Queue is empty.
                pass

            # Check if any stock is still running (i.e. its stop flag is False).
            running = any(not data["stop"] for data in self.stock_data.values())

            # If no stock is running and no enforced delay is active, revert the buttons to idle state.
            if not running and self.trading_start_time is None:
                self.set_buttons_idle()
            else:
                # If trading was started, check if the minimum 2-second delay has elapsed.
                if self.trading_start_time is not None:
                    elapsed = time.time() - self.trading_start_time
                    if elapsed > 2:
                        self.trading_start_time = None
                # While trading is ongoing or during the enforced delay, keep trading buttons active.
                self.set_buttons_trading()

            self.after(50, self.refresh_status)

        def sort_column(self, col):
            # Get all items in the tree.
            items = list(self.tree.get_children(''))
            # Decide conversion function based on column name.
            def convert(val):
                try:
                    # For numeric columns.
                    if col in ("target", "per_round", "secured"):
                        return int(val)
                except Exception:
                    pass
                return val.lower()  # Case-insensitive string sort.

            # Create a list of tuples: (item, value)
            data = [(item, convert(self.tree.set(item, col))) for item in items]
            # Toggle sorting order.
            descending = self.sorting_order.get(col, False)
            data.sort(key=lambda t: t[1], reverse=descending)
            # Reorder items in tree.
            for index, (item, _) in enumerate(data):
                self.tree.move(item, '', index)
            # Toggle the sort order for next time.
            self.sorting_order[col] = not descending

        def on_closing(self):
            # When GUI is closed, send a message to break main loop.
            cmd_queue.put({"action": "gui_closed"})
            self.destroy()

    app = TradingBotGUI(logger)
    app.mainloop()

# ============================================================
# Main Process: Bot Instance and Command Loop
# ============================================================
if __name__ == "__main__":
    # set multiporcess config for .exe
    multiprocessing.freeze_support()

    # Set logger
    utils.mk_folder("../log")
    logger, log_shutdown_event = utils.get_logger(
        name="Main",
        log_level=logging.DEBUG
    )

    # Set up multiprocessing queues.
    command_queue = multiprocessing.Queue()
    status_queue = multiprocessing.Queue()

    # Launch the GUI in its own process.
    gui_proc = multiprocessing.Process(target=gui_process, args=(command_queue, status_queue, logger))
    gui_proc.start()

    # SDK manager
    load_dotenv()  # Load .env
    my_id = os.getenv("ID")
    trade_password = os.getenv("TRADEPASS")
    cert_filepath = os.getenv("CERTFILEPATH")
    cert_password = os.getenv("CERTPASSS")
    active_account = os.getenv("ACTIVEACCOUNT")

    sdk_manager = SDKManager()
    is_success_login = sdk_manager.login(my_id, trade_password, cert_filepath, cert_password)

    if is_success_login:
        sdk_manager.set_active_account_by_account_no(active_account)

        # Instantiate the trading bot.
        bot = FubonMarginHero()
        bot.set_sdk_manager(sdk_manager=sdk_manager)

        # We'll use this variable to track the trading thread.
        trading_thread = None

        # Main command loop.
        running = True
        while running:
            try:
                cmd = command_queue.get(timeout=1)
                action = cmd.get("action")
                if action in ("add_stock", "remove_stock"):
                    targets = bot.get_targets()
                    if action == "add_stock":
                        symbol = cmd["symbol"]
                        targets[symbol] = [cmd["target"], cmd["per_round"]]
                        logger.info(f"Added stock {symbol}: target {cmd['target']}, per round {cmd['per_round']}")
                    elif action == "remove_stock":
                        symbol = cmd["symbol"]
                        if symbol in targets:
                            del targets[symbol]
                            logger.info(f"Removed stock {symbol}")
                    bot.set_targets(targets)
                elif action == "start_trading":
                    # Only start a new trading thread if none is running.
                    if trading_thread is None or not trading_thread.is_alive():
                        logger.info("Starting trading for all symbols...")
                        trading_thread = threading.Thread(target=bot.run, daemon=True)
                        trading_thread.start()
                    else:
                        logger.info("Trading is already running.")
                elif action == "stop_all":
                    # Manually stop all symbols.
                    for symbol in bot.get_targets().keys():
                        bot._stop_sign[symbol] = True
                    logger.info("Stop command issued for all symbols.")
                elif action == "stop_symbol":
                    symbol = cmd["symbol"]
                    bot._stop_sign[symbol] = True
                    logger.info(f"Stop command issued for symbol: {symbol}")
                elif action == "gui_closed":
                    logger.info("GUI closed. Exiting main loop.")
                    running = False
                else:
                    logger.info("Unknown command received.")
            except Exception:
                # Timeout if no command is received.
                pass

            # Periodically send status updates from the bot to the GUI.
            for symbol in bot.get_targets():
                update = {
                    "symbol": symbol,
                    "secured": bot._success_lot_counter.get(symbol, 0),
                    "stop": bot._stop_sign.get(symbol, True),
                    "pause": bot._pause_sign.get(symbol, False),
                    "error": bot._error_sign.get(symbol, False)
                }
                status_queue.put(update)
            time.sleep(0.5)

        # Cleanup
        gui_proc.terminate()
        bot.terminate()
        sdk_manager.terminate()
        if trading_thread is not None:
            trading_thread.join(5)
        log_shutdown_event.set()
        sys.exit()

    else:  # Fail to login
        logger.error("登入失敗！請檢查登入資訊及網路連線狀況，並重新啟動程式 ...")
        gui_proc.terminate()
        sdk_manager.terminate()
        log_shutdown_event.set()
        time.sleep(5)
        sys.exit()