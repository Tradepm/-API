import asyncio
import math
import sys
import threading
import logging
import time
import utils
import datetime
import traceback
import functools
from abc import ABC, abstractmethod
from zoneinfo import ZoneInfo
from sdk_manager_async import SDKManager, check_sdk
from fubon_neo.sdk import Order
from fubon_neo.constant import TimeInForce, OrderType, PriceType, MarketType, BSAction
from concurrent.futures import ThreadPoolExecutor
from collections import defaultdict


class Strategy(ABC):
    """
    Strategy template class
    """
    __version__ = "2024.0.7"

    def __init__(self, logger=None, log_level=logging.DEBUG):
        # Set logger
        log_shutdown_event = None
        if logger is None:
            current_date = datetime.datetime.now(ZoneInfo("Asia/Taipei")).date().strftime("%Y-%m-%d")
            utils.mk_folder("../log")
            logger, log_shutdown_event = utils.get_logger(
                name="Strategy",
                log_file=f"log/strategy_{current_date}.log",
                log_level=log_level
            )

        self.logger = logger
        self.logger_shutdown = log_shutdown_event

        # The sdk_manager
        self.sdk_manager: SDKManager | None = None

        # Coordination
        # self.__is_strategy_run = False

    """
        Public Functions
    """

    def set_sdk_manager(self, sdk_manager: SDKManager):
        self.sdk_manager = sdk_manager
        # self.logger.info(f"The SDKManager version: {self.sdk_manager.__version__}")

    @check_sdk
    def add_realtime_marketdata(self, symbol: str):
        """
         Add a realtime trade data websocket channel
        :param symbol: stock symbol (e.g., "2881")
        """
        self.sdk_manager.subscribe_realtime_trades(symbol)

    @check_sdk
    def remove_realtime_marketdata(self, symbol: str):
        """
        Remove a realtime market data websocket channel
        :param symbol: stock symbol (e.g., "2881")
        """
        self.sdk_manager.unsubscribe_realtime_trades(symbol)

    @abstractmethod
    @check_sdk
    def run(self):
        """
        Strategy logic to be implemented.
        """
        raise NotImplementedError("Subclasses must implement this method")


class FubonMarginHero(Strategy):
    __version__ = "2025.1.2.2"
    __start_time__ = datetime.time(8, 29, 59, 100)
    __end_time__ = datetime.time(8, 50)
    __order_marker__ = "IAMGROOT"

    def __init__(self, logger=None, log_level=logging.DEBUG):
        super().__init__(logger=logger, log_level=log_level)

        # Target setup
        self._targets: dict[str, list[int]] = {
            # First int is {total qty}, and the second is {per order qty}
            # "2881": [5, 1],
            # "2883": [3, 1],
        }

        # Status flags
        self._stop_sign: defaultdict[str, bool] = defaultdict(lambda: True)
        self._pause_sign: defaultdict[str, bool] = defaultdict(lambda: False)
        self._error_sign: defaultdict[str, bool] = defaultdict(lambda: False)
        self._entry_complete_sign: defaultdict[str, bool] = defaultdict(lambda: False)

        # Event counters
        self._status_nine_counter: defaultdict[str, int] = defaultdict(int)
        self._success_lot_counter: defaultdict[str, int] = defaultdict(int)
        self._exceed_trade_limit_counter: defaultdict[str, int] = defaultdict(int)

        # Coordinators
        self._lot_counter_lock: threading.Lock = threading.Lock()

        # Other resources
        self._event_loop: asyncio.AbstractEventLoop | None = None
        self._today: datetime.date = datetime.datetime.now(ZoneInfo("Asia/Taipei")).today().date()

        # ThreadPoolExecutor
        self._threadpool_executor = ThreadPoolExecutor()

    def run(self):
        asyncio.run(self._run_async())

    async def _run_async(self):
        try:
            loop = asyncio.get_running_loop()
            if sys.version_info >= (3, 12, 0):
                loop.set_task_factory(asyncio.eager_task_factory)

            # Start trade logic (per symbol)
            tasks = []

            for s in self._targets.keys():
                tasks.append(loop.create_task(self._operation_by_symbol(s)))

            # Wait until all tasks finished
            await asyncio.gather(*tasks)

        except Exception as err:
            self.logger.debug(f"_run_async exception: {err},\n{traceback.format_exc()}")

    async def _operation_by_symbol(self, symbol:str):
        async def retrieve_limitup_price(symbol:str) -> float | None:
            try:
                rest_client = self.sdk_manager.get_marketdata_rest_client()
                if rest_client is None:
                    return None

                response = rest_client.intraday.ticker(symbol=symbol)

                # Parsing the response result
                if 'statusCode' in response:
                    if response['statusCode'] == 429:  # Try again later
                        self.logger.debug(f"retrieve_limitup_price for symbol {symbol} encounter status code 429, " +
                                          f"will try later ...")
                        await asyncio.sleep(5)
                        return await retrieve_limitup_price(symbol)
                    else:  # Something went wrong
                        self.logger.debug(f"retrieve_limitup_price for symbol {symbol} error, response: {response}")
                        return None

                else:
                    # Check if the retrieved information is today's information
                    parsed_date = datetime.datetime.strptime(response['date'], '%Y-%m-%d').date()

                    if parsed_date == self._today:  # Correct date information
                        limitup_price = float(response['limitUpPrice'])
                        limitdown_price = float(response['limitDownPrice'])

                        if (limitup_price - limitdown_price) / limitdown_price > 0.3:  # Some ETF
                            reference_price = float(response['referencePrice'])

                            a_high_price = reference_price + int(reference_price * 0.1) if \
                                int(reference_price * 0.1) > 1 else reference_price + int(reference_price)

                            self.logger.warning(f"{symbol} has a wide gap between limit up / limit down prices, " +
                                                f"may use {a_high_price} instead of the limit up price {limitup_price}")

                            return a_high_price if a_high_price < limitup_price else limitup_price

                        else:
                            return limitup_price

                    else:  # Wrong date, try again later
                        self.logger.debug(f"The date of the retrieved ticker is not today, will try again later ...,\n" +
                                          f"self._today {self._today}, Response: {response}")
                        await asyncio.sleep(5)

                        if not self._stop_sign[symbol]:
                            return await retrieve_limitup_price(symbol)
                        else:
                            self.logger.debug(f"Stop-sign activated for {symbol}, stop retrieve the ticker")
                            return None

            except Exception as err:
                self.logger.error(f"retrieve_limitup_price exception: {err}, " +
                                  f"symbol {symbol},\n{traceback.format_exc()}")
                return None

        def trigger_pause_if_place_order_failed(fut: asyncio.Future):
            try:
                result = fut.result()  # Get the result of the function call
                #self.logger.debug("Operation completed successfully with result:", result)

                if (not result.is_success) and ("connection is closed" in result.message):
                    self.logger.warning(f"The underlying conection is closed. Pause place order for a while.")
                    asyncio.run_coroutine_threadsafe(
                        self._trigger_and_release_pause_in_time(symbol, True, 5),
                        loop = self._event_loop
                    )

            except Exception as err:
                self.logger.warning(f"Operation raised an exception: {err}, future: {fut}")

        # Main logic of _operation_by_symbol
        try:
            self._event_loop = asyncio.get_running_loop()

            # Reset the flags and counters
            self._stop_sign[symbol] = False
            self._pause_sign[symbol] = False
            self._error_sign[symbol] = False
            self._entry_complete_sign[symbol] = False

            self._status_nine_counter[symbol] = 0
            self._exceed_trade_limit_counter[symbol] = 0

            # Preparation 1: Get the limit-up price
            limitup_price = await retrieve_limitup_price(symbol)

            if limitup_price is None:
                self.logger.error(f"Cannot retrieve the limit up price information for symbol {symbol}! " +
                                  f"Will ignore this symbol")

                self._error_sign[symbol] = True
                self._stop_sign[symbol] = True
                return

            # Preparation 2: Establish the order object
            order = Order(
                buy_sell=BSAction.Sell,
                symbol=symbol,
                price=f"{limitup_price:.2f}",
                quantity=int(self._targets[symbol][1] * 1000),
                market_type=MarketType.Common,
                price_type=PriceType.Limit,
                time_in_force=TimeInForce.ROD,
                order_type=OrderType.Short,
                user_def=self.__order_marker__  # Order identifier
            )

            place_order_partial = functools.partial(
                self.sdk_manager.sdk.stock.place_order,
                self.sdk_manager.active_account,
                order,
                unblock=True
            )

            # Step 1: Wait until the designated time
            self.logger.debug(f"{symbol} Check current time and wait until the trigger time ...")
            now_time = datetime.datetime.now(ZoneInfo("Asia/Taipei")).time()
            while now_time < self.__start_time__:
                await asyncio.sleep(0.005)
                now_time = datetime.datetime.now(ZoneInfo("Asia/Taipei")).time()

            self.logger.debug(f"{symbol} start sending orders")
            # Step 2: Loop over and keep sending orders, until stop conditions met
            while (now_time < self.__end_time__) and \
                    (not self._stop_sign[symbol]) and \
                    (not self._entry_complete_sign[symbol]) and \
                    (self._targets[symbol][0] > self._success_lot_counter[symbol]):
                # Shoot orders (if stop conditions are not triggered)
                order_rounds = math.ceil((self._targets[symbol][0] - self._success_lot_counter[symbol]) /
                                   self._targets[symbol][1])

                for _ in range(int(order_rounds)):
                    if not self._pause_sign[symbol]:
                        future = self._event_loop.run_in_executor(
                            self._threadpool_executor,
                            place_order_partial,
                        )

                        # Attach the callback; it will be invoked once the future is done
                        future.add_done_callback(trigger_pause_if_place_order_failed)

                    else:
                        break

                # Sleep and update now_time
                await asyncio.sleep(1)
                now_time = datetime.datetime.now(ZoneInfo("Asia/Taipei")).time()

            self.logger.debug(f"{symbol} entry round completed ...")
            self._entry_complete_sign[symbol] = True  # Re-confirm that entry complete sign is set True
            self._pause_sign[symbol] = False  # Re-confirm that pause sign is set False

            # Step 3: Offload excessive orders
            if not self._stop_sign[symbol]:
                await asyncio.sleep(2)  # Pause to make sure all order feedback has arrived
                await self._offload_excessive_orders(symbol)
            else:
                self.logger.debug(f"{symbol} stop-sign is on, do not proceed to the offload logic")

            # Finish step
            self._stop_sign[symbol] = True
            self._pause_sign[symbol] = False  # Re-confirm that pause sign is set False

        except Exception as err:
            self.logger.debug(f"Symbol {symbol} operation exception: {err},\n{traceback.format_exc()}")
            self._error_sign[symbol] = True
            self._stop_sign[symbol] = True
            self._pause_sign[symbol] = False  # Re-confirm that pause sign is set False

    async def _offload_excessive_orders(self, symbol):
        try:
            # Task complete if there is no excessive order
            if self._success_lot_counter[symbol] <= self._targets[symbol][0]:
                self.logger.debug(f"Symbol {symbol} has no excessive orders, ignore offloading ...")
                return

            # Step 1: Retrieve order status
            success_attempt = False
            response = None
            while not success_attempt:
                response = self.sdk_manager.sdk.stock.get_order_results(self.sdk_manager.active_account)
                success_attempt = response.is_success

                if not success_attempt:
                    self.logger.debug(f"訂單狀態查詢失敗，稍後重試 ... response: {response}")
                    await asyncio.sleep(2)

            order_status:list = list(reversed(response.data))

            # Step 2: Cancel or modify order recursively
            indicator = 0
            success_lot_counter_temp = self._success_lot_counter[symbol]

            while success_lot_counter_temp > self._targets[symbol][0]:
                # Get excessive_lot count
                excessive_lot = success_lot_counter_temp - self._targets[symbol][0]

                # Get the target order
                target_order = order_status[indicator]
                while (target_order.stock_no != symbol) or (target_order.user_def != self.__order_marker__) or\
                        (target_order.status != 10):
                    indicator += 1  # Update the indicator for the next target order
                    target_order = order_status[indicator]


                self.logger.debug(f"Symbol:{symbol}, indicator: {indicator}, target_order:\n{target_order}")
                indicator += 1  # Update the indicator for the next target order

                # Process the target order
                target_order_lot = int(target_order.after_qty / 1000)

                if target_order_lot <= excessive_lot:
                    # Cancel the order
                    cancel_order_partial = functools.partial(
                        self.sdk_manager.sdk.stock.cancel_order,
                        self.sdk_manager.active_account,
                        target_order,
                        unblock=False
                    )

                    future = self._event_loop.run_in_executor(
                        self._threadpool_executor,
                        cancel_order_partial,
                    )

                else:  # The order has more qty than the excessive count
                    # Modify the order to reduce the quantity
                    remain_qty = int(1000 * (target_order_lot - excessive_lot))
                    modify_qty_obj = self.sdk_manager.sdk.stock.make_modify_quantity_obj(target_order, remain_qty)

                    modify_order_partial = functools.partial(
                        self.sdk_manager.sdk.stock.modify_quantity,
                        self.sdk_manager.active_account,
                        modify_qty_obj,
                        unblock=False
                    )

                    future = self._event_loop.run_in_executor(
                        self._threadpool_executor,
                        modify_order_partial,
                    )

                ## CAUTION: We do not update self._success_lot_counter here, we update it in the callback function
                result = await future

                if not result.is_success:
                    self.logger.debug(f"{symbol} modify order {target_order.seq_no} faild! " +
                                      f"msg: {result.message}, data:\n{result.data}")

                else:
                    self.logger.debug(f"{symbol} offload {target_order_lot} lots")
                    success_lot_counter_temp -= target_order_lot

            # Call the function itself again to make sure that it is true that all excessive orders
            # has been successful offloaded
            await asyncio.sleep(5)
            await self._offload_excessive_orders(symbol)

        except AttributeError as err:
            self.logger.debug(f"_offload_excessive_orders exception: {err}, " +
                              f"symbol {symbol} \n{traceback.format_exc()}.\nTry again ...")

            # Probably sdk temporarily disconnected, wait a while and retry
            await asyncio.sleep(2)
            await self._offload_excessive_orders(symbol)

        except Exception as err:
            self.logger.debug(f"_offload_excessive_orders exception: {err}, " +
                              f"symbol {symbol} \n{traceback.format_exc()}")

    async def _trigger_and_release_pause_in_time(self, set_symbol: str, set_value: bool, sleep_time: float):
        if self._pause_sign[set_symbol] != set_value:
            self.logger.debug(f"{set_symbol} set pause_sign to {set_value} for {sleep_time} seconds")

            self._pause_sign[set_symbol] = set_value
            await asyncio.sleep(sleep_time)
            self._pause_sign[set_symbol] = (not set_value)

            self.logger.debug(f"{set_symbol} set pause_sign to {not set_value}")

        else:
            self.logger.debug(f"{set_symbol} already have the pause_sign equals {set_value}, ignore the request")

    async def _trigger_and_release_pause_if_quota_available(self, set_symbol: str):
        try:
            # Set the pause sign for the symbol
            if not self._pause_sign[set_symbol]:
                self.logger.debug(f"{set_symbol} set pause_sign to {True}, until the quota is available or end_time is reached")
                self._pause_sign[set_symbol] = True

                # Start checking the quota information
                now_time = datetime.datetime.now(ZoneInfo("Asia/Taipei")).time()

                while now_time < self.__end_time__:
                    # Check the current short sell quota
                    response = self.sdk_manager.sdk.stock.margin_quota(self.sdk_manager.active_account, set_symbol)

                    if response.is_success:  # Get data successfully
                        quota = int(response.data.shortsell_tradable_quota)

                        if quota >= self._targets[set_symbol][1]:  # Enough quota now! Release the pause
                            self.logger.debug(f"{set_symbol} set pause_sign to {False} because quota is available now. " + 
                                            f"Quota: {quota}, per order lot: {self._targets[set_symbol][1]}")

                            self._pause_sign[set_symbol] = False
                            return  ############## Exit early ##############

                        else:
                            self.logger.debug(f"{set_symbol} 可用融券配額: {quota}")

                    else:  # Failed to get data, wait and try again
                        self.logger.debug(f"Failed to get quota data for symbol {set_symbol}, " +
                                          f"will wait and try again. Response:\n{response}")
                        await asyncio.sleep(10)

                    # Sleep for a while and update the current time for the next loop
                    await asyncio.sleep(1)
                    now_time = datetime.datetime.now(ZoneInfo("Asia/Taipei")).time()


                # End time happens
                self.logger.info(f"{set_symbol} reached end_time, no quota available")
                self._error_sign[set_symbol] = True
                self._stop_sign[set_symbol] = True

            else:  # pause-sign is already activated
                self.logger.debug(f"Pause sign is already set for {set_symbol}")
                return  ############## Exit early ##############

        except Exception as err:
            self.logger.error(f"_trigger_and_release_pause_if_quota_available err: {err}\n{traceback.format_exc()}")
            self.logger.warning(f"Failed to process 'pause and check quota' for symbol {set_symbol}, set error-sign")
            
            self._error_sign[set_symbol] = True
            self._stop_sign[set_symbol] = True

    def get_targets(self):
        return self._targets

    def set_targets(self, targets: dict[str, list[int]]):
        self._targets = targets
        self.logger.debug(f"New targets: {targets}")

    def set_sdk_manager(self, sdk_manager: SDKManager):
        try:
            super().set_sdk_manager(sdk_manager)
            time.sleep(0.2)
            # Set callbacks
            self.sdk_manager.set_trade_handle_func("on_order", self._on_order_callback)
            self.sdk_manager.set_trade_handle_func("on_order_changed", self._on_order_change_callback)
            time.sleep(0.2)

        except Exception as err:
            self.logger.error(f"Set SDK-manager exception: {Exception} \n{traceback.format_exc()}")

    def terminate(self):
        self.logger_shutdown.set()

    # ---------------------------------------------------------------
    #                          Callbacks
    # ---------------------------------------------------------------
    def _on_order_callback(self, code, content):
        try:
            account = content.account
            status = int(content.status)
            user_def = content.user_def
            symbol = content.stock_no

            # Skip irrelevant information
            if account != self.sdk_manager.active_account.account:
                return
            elif (user_def is None) or (user_def != self.__order_marker__):
                self.logger.debug(f"Not program order callback, user_def {user_def}")
                return

            # Process the information
            if status == 10:  # success order
                # Precautious error notification
                if content.quantity % 1000 != 0:
                    self.logger.warning(f"新單回報數量包含零股，請手動進行確認！ 回報:\n{content}")
                elif (content.buy_sell != BSAction.Sell) or (content.order_type != OrderType.Short):
                    self.logger.warning(f"新單回報買賣別 {content.buy_sell} ")

                # Update the total qty of successful orders
                qty = int(content.quantity)
                lot_qty = int(qty / 1000)

                with self._lot_counter_lock:
                    self._success_lot_counter[symbol] += lot_qty
                    self.logger.debug(f"{symbol} success lot counter update: {self._success_lot_counter[symbol]}, " +
                                      f"lot_qty: {lot_qty}")

                    # Check to shoot the stop-sign
                    if self._success_lot_counter[symbol] >= self._targets[symbol][0]:
                        # if not self._stop_sign[symbol]:
                        #     self._stop_sign[symbol] = True
                        #     self.logger.debug(f"{symbol} success lots have reached to target, activate the stop-sign")
                        if not self._entry_complete_sign[symbol]:
                            self._entry_complete_sign[symbol] = True
                            self.logger.debug(f"{symbol} success lots have reached to target, " +
                                              f"activate the entry complete sign")

            elif status == 90:  # Failed order
                # Figure out why the order failed, update the stop-sign if necessary
                ## error_message contains
                ### "時間未到" => Well, keep trying
                ### "業務流量控管" => (Maybe Wait?) and keep trying
                ### "停券" or "不在可交易商品中" or "價格查詢錯誤" or "資料不存在" => Not hope, stop trying
                ### "額度超限" => Pause and keep checking until the end time? Some amount limit could be released
                ### "融券配額不足" => Pause and check API's "shortsell_tradable_quota" until enough quota is available
                error_message = content.error_message if content.error_message is not None else ""

                if "業務流量控管" in error_message:
                    self.logger.info(f"下單流量超限，稍後再試 ...")
                    asyncio.run_coroutine_threadsafe(
                        self._trigger_and_release_pause_in_time(symbol, True, 1),
                        loop=self._event_loop
                    )

                elif ("停券" in error_message) or ("不在可交易商品中" in error_message) or \
                        ("價格查詢錯誤" in error_message) or ("資料不存在" in error_message):
                    self.logger.info(f"{symbol}  無法正常下單, message: {error_message}")
                    self._stop_sign[symbol] = True
                    self._error_sign[symbol] = True

                elif "額度超限" in error_message:
                    self._exceed_trade_limit_counter[symbol] += 1

                    if self._exceed_trade_limit_counter[symbol] <= 2:
                        self.logger.info(f"{symbol} 額度超限，稍後嘗試下單 (重試次數: {self._exceed_trade_limit_counter[symbol]}) ...")
                        asyncio.run_coroutine_threadsafe(
                            self._trigger_and_release_pause_in_time(symbol, True, 10),
                            loop=self._event_loop
                        )
                    
                    else:
                        self.logger.info(f"{symbol} 額度超限重試超過 2 次，取消後續下單 ...")
                        self._stop_sign[symbol] = True
                        self._error_sign[symbol] = True

                elif "時間未到" in error_message:
                    pass

                elif "融券配額不足" in error_message:
                    self.logger.info(f"{symbol} 融券配額不足，將進入查詢階段，待有配額再行下單 ...")
                    asyncio.run_coroutine_threadsafe(
                        self._trigger_and_release_pause_if_quota_available(symbol),
                        loop=self._event_loop
                    )

                else:
                    self.logger.debug(f"Unhandled error message: {error_message}. Content:\n{content}")

            elif status == 9:  # Timeout?!
                # This is not normal, should have a counter to keep track how often this happened
                self._status_nine_counter[symbol] += 1

                self.logger.warning(f"Place order for {symbol} encounter status 9")
                self.logger.debug(f"\tcurrent occurrence: {self._status_nine_counter[symbol]}")

                if self._status_nine_counter[symbol] <= 2:  # Pause and try again later
                    asyncio.run_coroutine_threadsafe(
                        self._trigger_and_release_pause_in_time(symbol, True, 5),
                        loop=self._event_loop
                    )

                else:  # Terminate the operation
                    self.logger.warning(f"Too many status 9 while placing orders for {symbol}, stop trying")
                    self._stop_sign[symbol] = True
                    self._error_sign[symbol] = True

            else:  # Something not relevant
                pass

        except Exception as err:
            self.logger.debug(f"_on_order_callback exception: {err},\n{traceback.format_exc()} \n {content}")

    def _on_order_change_callback(self, code, content):
        try:
            account = content.account
            function_type = int(content.function_type)
            status = int(content.status)
            user_def = content.user_def
            symbol = content.stock_no

            # Skip irrelevant information
            if account != self.sdk_manager.active_account.account:
                return
            elif (user_def is None) or (user_def != self.__order_marker__):
                return

            # Process the information
            if status == 30:  # 刪單成功
                before_qty_lot = int(content.before_qty / 1000)
                with self._lot_counter_lock:
                    self._success_lot_counter[symbol] -= before_qty_lot

            elif status == 10 and function_type == 20:  #  改量成功
                before_qty_lot = int(content.before_qty / 1000)
                after_qty_lot = int(content.after_qty / 1000)
                with self._lot_counter_lock:
                    self._success_lot_counter[symbol] -= (before_qty_lot - after_qty_lot)

            else:  # Something not relevant
                pass

        except Exception as err:
            self.logger.debug(f"_on_order_change_callback exception: {err},\n{traceback.format_exc()}")

